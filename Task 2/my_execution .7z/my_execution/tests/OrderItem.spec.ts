import {test} from "@playwright/test";
import {Registration} from "../pages/registartion";
import {Login} from "../pages/Login";
import * as loginData from "../data/logindata.json";
import * as Registerdata from "../data/Registerdata.json";
import { Additem } from "../pages/AddItem";
import { Checkout } from "../pages/Checkout";
import* as checkoutdata from "../data/Checkoutdata.json";

test.describe("Task Suite",()=>{

    test.beforeEach(async({page})=>{
        let Reg1:Registration=new Registration(page);
        let Reg2:Registration=new Registration(page);
        await page.goto("https://practicesoftwaretesting.com/auth/register");
        await Reg1.Register1(Registerdata.FirstName,Registerdata.LastName,Registerdata.DateOfBirth,Registerdata.Address,
            Registerdata.postcode,Registerdata.city,Registerdata.state);
        await Reg2.Register2(Registerdata.country,Registerdata.phone,Registerdata.password,Registerdata.EmailAddress);
                
             });

             test("Order an item",async({page})=>{
                await page.pause();
        
            });

    test.beforeEach(async({page})=>{
        let loginn:Login=new Login(page);
        await page.goto("https://practicesoftwaretesting.com/auth/login");
     await loginn.login(loginData.email,loginData.password);

    });
    
    test.beforeEach(async({page})=>{

        let item:Additem=new Additem(page);
        await item.Add();

         });
       
         test.beforeEach(async({page})=>{
            let loginn:Login=new Login(page);
         await loginn.login(loginData.email,loginData.password);
    
        });

        test.beforeEach(async({page})=>{
            let buyItem:Checkout=new Checkout(page);
         await buyItem.CheckoutProceed(checkoutdata.address,checkoutdata.city,checkoutdata.country,checkoutdata.postcode,checkoutdata.state)
    
         
        });

 
});

