import { Locator, Page } from "@playwright/test";

export class Checkout{

page:Page
    private readonly Address:Locator;
    private readonly City:Locator;
    private readonly State:Locator;
    private readonly Country:Locator;
    private readonly Postcode:Locator;
    private readonly Proceed:Locator;
    private readonly Payment:Locator;
    private readonly Confirm:Locator;
        
    
    //assign value to the variable here or in the constructor only

constructor(page){
this.page=page;
this.Address=page.getByPlaceholder('Your Address *');
this.City=page.getByPlaceholder('Your City *');
this.State=page.getByPlaceholder('State *');
this.Country=page.getByPlaceholder('Your country *');
this.Postcode=page.getByPlaceholder('Your Postcode *');
this.Proceed=page.getByRole('button', { name: 'Proceed to checkout ' });
this.Payment= page.getByTestId('payment-method');
this.Confirm= page.getByRole('button', { name: ' Confirm  ' });


}    

async CheckoutProceed(address:string,city:string,state:string,
    country:string,Postcode:string){
    await this.Address.fill(address);
    await this.City.fill(city);
    await this.State.fill(state);
    await this.Country.fill(country);
    await this.Postcode.fill(Postcode);
    await this.Proceed.click();
    await this.Payment.fill('Cash on Delivery');
    await this.Confirm.click();


}
}
