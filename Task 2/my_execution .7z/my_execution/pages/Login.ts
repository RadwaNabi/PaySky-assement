import { Locator, Page } from "@playwright/test";

export class Login{

page:Page
    private readonly email:Locator;
    private readonly password:Locator;
    private readonly loginBtn:Locator;
    private readonly Home:Locator;

    //assign value to the variable here or in the constructor only

constructor(page){
this.page=page;
this.email=page.getByLabel('Email address *');
this.password=page.getByPlaceholder('Your password');
this.loginBtn=page.getByRole('button', { name: 'Login' });
this.Home=page.getByAltText('Home');
}    

async login(email:string,password:string){
    await this.email.fill(email);
    await this.password.fill(password);
    await this.loginBtn.click();
    await this.Home.click();

}

}
