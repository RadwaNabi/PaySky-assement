import { Locator, Page } from "@playwright/test";

export class Additem{

page:Page
   
    private readonly Item:Locator;
    private readonly AddBtn:Locator;
    private readonly cartBtn:Locator;
    private readonly checkoutBtn:Locator;



    

    //assign value to the variable here or in the constructor only

constructor(page){
this.page=page;
this.Item=page.getByAltText('Combination Pliers');
this.AddBtn=page.locator('//*[@id="btn-add-to-cart"]');
this.cartBtn=page.getByLabel('cart');
this.checkoutBtn=page.getByRole('button', { name: 'Login' });


}    

async Add(){
    await this.Item.click();
    await this.AddBtn.click();
    await this.cartBtn.click();
    await this.checkoutBtn.click();

}

}
